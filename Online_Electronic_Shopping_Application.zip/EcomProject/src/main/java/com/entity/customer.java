package com.entity;

public class customer {

	private String Name;
	private String Password;
	private String Email_Id;
	private int Contact_No;
	
	
	
	
	public customer() {
		
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getEmail_Id() {
		return Email_Id;
	}
	public void setEmail_Id(String email_Id) {
		Email_Id = email_Id;
	}
	public int getContact_No() {
		return Contact_No;
	}
	public void setContact_No(int contact_No) {
		Contact_No = contact_No;
	}
	
	
	
	
}
